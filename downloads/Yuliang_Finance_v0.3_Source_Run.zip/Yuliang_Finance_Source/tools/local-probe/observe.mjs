// Passive adapter only. No replay, routing, clicks, input, screenshots or HAR.
export function attachObserver(context,session){
  let active=0;const pending=new Set();
  const handler=response=>{
    const phase=session.phase;if(!['manual_query','quiet_window'].includes(phase))return;
    if(active>=2){session.counts.busy++;return;}
    active++;
    const task=(async()=>{
      const request=response.request();
      const meta={url:response.url(),method:request.method(),status:response.status(),resourceType:request.resourceType(),contentType:await response.headerValue('content-type'),contentLength:null};
      const length=await response.headerValue('content-length');if(length&&/^\d+$/.test(length))meta.contentLength=Number(length);
      if(!session.shouldRead(meta))return;
      const body=await response.body();session.observe(meta,body.toString('utf8'),phase);
    })().catch(()=>{session.counts.readFailed++;}).finally(()=>{active--;pending.delete(task);});
    pending.add(task);
  };
  context.on('response',handler);
  return {detach(){context.off('response',handler);},async drain(){await Promise.race([Promise.allSettled([...pending]),new Promise(resolve=>{const timer=setTimeout(resolve,3000);timer.unref?.();})]);}};
}
