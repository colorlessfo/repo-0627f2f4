import {createHmac,randomBytes} from 'node:crypto';

export const PLATFORMS={
  alipay:{name:'支付宝',home:'https://www.alipay.com/',domains:['alipay.com']},
  bankcomm:{name:'交通银行',home:'https://www.bankcomm.com/',domains:['bankcomm.com']},
  wechat:{name:'微信支付',home:'https://weixin.qq.com/',domains:['weixin.qq.com','tenpay.com','wechatpay.cn'],limitation:'个人账单可能仅在手机 App 提供；商户账单不等于个人全量流水。'},
  wealth:{name:'微信理财通',home:'https://www.tenpay.com/',domains:['tenpay.com']},
  csc108:{name:'蜻蜓点金',home:'https://www.csc108.com/',domains:['csc108.com']}
};
// Only pre-reviewed generic field names are exported. All other JSON keys are
// run-specific HMAC labels: keys themselves can contain account IDs or names.
const aliases={
  data:'container',result:'container',response:'container',payload:'container',
  records:'rows',rows:'rows',list:'rows',items:'rows',recordList:'rows',tradeList:'rows',transactions:'rows',details:'rows',
  tradeNo:'recordId',trade_no:'recordId',transactionId:'recordId',transaction_id:'recordId',orderId:'recordId',order_no:'recordId',bizNo:'recordId',id:'possibleId',
  amount:'amount',money:'amount',totalAmount:'amount',total_amount:'amount',tradeAmount:'amount',income:'amount',expense:'amount',
  gmtCreate:'time',gmt_create:'time',tradeTime:'time',trade_time:'time',transactionTime:'time',createTime:'time',date:'time',tradeDate:'time',
  direction:'direction',inOutType:'direction',in_out:'direction',fundFlow:'direction',type:'possibleType',tradeType:'possibleType',
  status:'status',tradeStatus:'status',state:'status',currency:'currency',currencyCode:'currency',
  accountId:'accountIdentifier',account_id:'accountIdentifier',accountNo:'accountIdentifier',cardNo:'accountIdentifier',userId:'accountIdentifier',
  total:'pagination',totalCount:'pagination',total_count:'pagination',pageNo:'pagination',pageNum:'pagination',pageSize:'pagination',page_count:'pagination',totalPages:'pagination',hasNext:'pagination',nextCursor:'pagination',cursor:'pagination',
  code:'resultCode',success:'resultStatus',msg:'message',message:'message',
  '金额':'amount','交易金额':'amount','交易时间':'time','交易号':'recordId','收支':'direction','交易状态':'status','总页数':'pagination','总条数':'pagination'
};
const routeWords=new Set(['api','ajax','record','records','trade','trades','query','list','detail','transaction','transactions','account','accounts','bill','bills','statement','statements','history','index','data','json','do','htm','html','service','gateway','mobile','web','pc','v1','v2','v3','standard']);
const selectors=new Set(['action','method','operation','service','api','cmd','function']);
export function inScope(raw,platform){
  let u;try{u=new URL(raw);}catch{return false;}
  return Object.hasOwn(PLATFORMS,platform)&&u.protocol==='https:'&&!u.username&&!u.password&&(!u.port||u.port==='443')&&PLATFORMS[platform].domains.some(d=>u.hostname===d||u.hostname.endsWith('.'+d));
}
export class ProbeSession{
  constructor(platform,{clock=()=>new Date().toISOString(),salt=randomBytes(32)}={}){
    if(!Object.hasOwn(PLATFORMS,platform))throw new Error('未知平台');this.platform=platform;this.clock=clock;this.salt=salt;this.phase='idle';this.startedAt=clock();this.candidates=new Map();
    this.counts={outOfScope:0,notJson:0,tooLarge:0,unsupportedMethod:0,transportAuthDenied:0,transportError:0,invalidJson:0,busy:0,readFailed:0,inspected:0,overflow:0};
  }
  hash(value){return createHmac('sha256',this.salt).update(String(value)).digest('hex').slice(0,24);}
  field(key){return Object.hasOwn(aliases,key)?{name:key,role:aliases[key]}:{name:'field_'+this.hash(key),role:'unknown'};}
  setPhase(phase){if(!['idle','manual_query','quiet_window','paused','finished'].includes(phase))throw new Error('无效阶段');this.phase=phase;}
  shouldRead(meta){
    if(!['manual_query','quiet_window'].includes(this.phase))return false;
    if(!inScope(meta.url,this.platform)){this.counts.outOfScope++;return false;}
    if(!['GET','POST'].includes(meta.method)){this.counts.unsupportedMethod++;return false;}
    if(!['xhr','fetch'].includes(meta.resourceType)){this.counts.notJson++;return false;}
    if([401,403].includes(meta.status)){this.counts.transportAuthDenied++;this.phase='paused';return false;}
    if(meta.status<200||meta.status>=300){this.counts.transportError++;return false;}
    if(!/^(application\/(?:[a-z0-9.+-]*\+)?json)(?:\s*;|$)/i.test(meta.contentType||'')){this.counts.notJson++;return false;}
    if(meta.contentLength!==null&&meta.contentLength>2*1024*1024){this.counts.tooLarge++;return false;}
    return true;
  }
  structure(value){
    const arrays=[];let nodes=0,limited=false;
    const visit=(v,path,depth)=>{
      if(++nodes>500||depth>7){limited=true;return {type:'limited'};}
      if(v===null)return {type:'null'};
      if(Array.isArray(v)){
        const info={path,observedLength:v.length,fields:[]};arrays.push(info);
        const fields=new Map();for(const row of v.slice(0,3))if(row&&typeof row==='object'&&!Array.isArray(row))for(const key of Object.keys(row).slice(0,50)){const f=this.field(key);fields.set(f.name,f);}
        info.fields=[...fields.values()].sort((a,b)=>a.name.localeCompare(b.name));
        const roles=new Set(info.fields.map(f=>f.role));info.possibleTransactions=roles.has('amount')&&roles.has('time')&&(roles.has('recordId')||roles.has('possibleId')||roles.has('direction'));
        const variants=[...new Map(v.slice(0,3).map(x=>{const s=visit(x,[...path,'[]'],depth+1);return [JSON.stringify(s),s];})).values()];
        return {type:'array',items:variants.sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)))};
      }
      if(typeof v==='object'){const keys=Object.keys(v);if(keys.length>60)limited=true;return {type:'object',fields:keys.slice(0,60).map(key=>{const f=this.field(key);return {...f,value:visit(v[key],[...path,f.name],depth+1)};}).sort((a,b)=>a.name.localeCompare(b.name))};}
      return {type:typeof v}; // Never include string contents, numeric or boolean values.
    };
    const schema=visit(value,[],0);return {schema,arrays,limited};
  }
  observe(meta,body,phase=this.phase){
    // Recheck phase after awaiting a response body; a manual query that finishes
    // in a later phase is still manual evidence, never quiet-window evidence.
    if(!['manual_query','quiet_window'].includes(phase)||!['manual_query','quiet_window'].includes(this.phase))return;
    if(!inScope(meta.url,this.platform)||!['GET','POST'].includes(meta.method))return;
    if(Buffer.byteLength(body)>2*1024*1024){this.counts.tooLarge++;return;}
    let json;try{json=JSON.parse(body);}catch{this.counts.invalidJson++;return;}
    const shape=this.structure(json);this.counts.inspected++;
    const u=new URL(meta.url),queryKeys=[...new Set(u.searchParams.keys())].sort();
    const operation=[...u.searchParams].filter(([key])=>selectors.has(key)).sort(([a,av],[b,bv])=>a.localeCompare(b)||av.localeCompare(bv));
    const endpointId=this.hash(JSON.stringify([u.origin,u.pathname,queryKeys,operation,meta.method]));
    const schemaId=this.hash(JSON.stringify(shape.schema)),id=endpointId+':'+schemaId;
    let c=this.candidates.get(id);
    if(!c){
      if(this.candidates.size>=50){this.counts.overflow++;return;}
      const pathShape=u.pathname.split('/').filter(Boolean).map(segment=>routeWords.has(segment)?segment:'segment_'+this.hash(segment)).slice(0,12);
      c={endpointId,schemaId,method:meta.method,pathShape,queryKeys:queryKeys.slice(0,30).map(key=>this.field(key).name),schema:shape.schema,schemaLimited:shape.limited,arrays:shape.arrays,manualResponses:0,quietWindowResponses:0,firstObservedAt:this.clock(),lastObservedAt:this.clock(),requiresEndpointReview:true};this.candidates.set(id,c);
    }
    c[phase==='manual_query'?'manualResponses':'quietWindowResponses']++;c.lastObservedAt=this.clock();c.arrays=shape.arrays;
  }
  report(){
    return {tool:'Yuliang Local Read-only Probe',version:'0.3.0',platform:this.platform,startedAt:this.startedAt,generatedAt:this.clock(),phase:this.phase,counters:{...this.counts},candidates:structuredClone([...this.candidates.values()]),automaticSyncVerified:false,sourceDataTime:'unknown',historyCoverage:'unknown',quietWindowIsProofOfNewTransactions:false,limitations:['仅被动观察用户在官方查询页面正常收到的 JSON 响应；未重放任何接口。','静默观察阶段的响应不证明新流水已入账、账号正确、日期覆盖或分页完整。','URL、查询值、请求/响应头、正文值、Cookie、口令均不导出。未知字段名使用本次运行专用 HMAC。','微信手机个人账单是否存在可用桌面入口仍待验证；商户接口不等于个人流水。']};
  }
}
