import {chromium} from 'playwright';
import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {mkdir,writeFile,chmod} from 'node:fs/promises';
import {homedir} from 'node:os';
import path from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {PLATFORMS,ProbeSession} from './core.mjs';
import {attachObserver} from './observe.mjs';

const args=process.argv.slice(2);
if(args.includes('--help')){
  console.log('余量财务本机接入诊断 v0.3\nnode tools/local-probe/run.mjs [--provider alipay|bankcomm|wechat|wealth|csc108] [--seconds 120]\n由本人在独立 Edge 窗口登录。仅被动观察；不执行查询重放、付款或交易。');
  process.exit(0);
}
function option(name){const i=args.indexOf(name);return i===-1?undefined:args[i+1];}
for(let i=0;i<args.length;i+=2)if(!['--provider','--seconds'].includes(args[i])||!args[i+1]){console.error('参数无效，请使用 --help。');process.exit(1);}
const seconds=option('--seconds')===undefined?120:Number(option('--seconds'));
if(!Number.isInteger(seconds)||seconds<30||seconds>600){console.error('观察时间须为 30–600 秒。');process.exit(1);}
if(option('--provider')&&!Object.hasOwn(PLATFORMS,option('--provider'))){console.error('平台参数无效。');process.exit(1);}
if(process.platform!=='win32'){console.error('此交互入口需要 Windows 和已安装的 Edge；Linux 模拟测试请用 npm run test:probe:browser。');process.exit(1);}

const terminal=createInterface({input:stdin,output:stdout}),controller=new AbortController();
let context,observer,session,reportPath,interrupted=false,outcome='incomplete';
const onStop=()=>{interrupted=true;controller.abort();terminal.close();};
process.once('SIGINT',onStop);process.once('SIGTERM',onStop);
try{
  console.log('\n余量财务 · 收支自动同步接入诊断 v0.3\n只观察数据结构，不自动点击、刷新、下单或转账。请勿向聊天发送账户凭据。\n');
  const ids=Object.keys(PLATFORMS);let provider=option('--provider');
  if(!provider){ids.forEach((id,i)=>console.log(`${i+1}. ${PLATFORMS[id].name}`));const choice=await terminal.question('选择平台（默认 1 支付宝）：',{signal:controller.signal});provider=ids[Number(choice.trim()||'1')-1];if(!provider)throw new Error('INVALID_CHOICE');}
  const root=path.join(process.env.LOCALAPPDATA||path.join(homedir(),'AppData','Local'),'YuliangFinance');
  const profile=path.join(root,'profiles',provider),reports=path.join(root,'reports');
  await mkdir(profile,{recursive:true});await mkdir(reports,{recursive:true});
  session=new ProbeSession(provider);
  console.log(`\n将打开 ${PLATFORMS[provider].name} 独立 Edge 窗口。登录状态只保存在本机专用配置目录。`);
  console.log('不要使用这个窗口付款、交易或管理账户设置；仅登录和查询。');
  context=await chromium.launchPersistentContext(profile,{channel:'msedge',headless:false,acceptDownloads:false});
  observer=attachObserver(context,session);
  const page=context.pages()[0]||await context.newPage();
  await page.goto(PLATFORMS[provider].home,{waitUntil:'domcontentloaded',timeout:60000}).catch(()=>console.log('官网加载未完成。请在打开的 Edge 内从熟悉的官网自行导航；不要使用不明链接。'));
  console.log('\n第一步：在 Edge 官方界面自己登录、完成验证，进入本人“交易记录/账户明细”页。');
  if(PLATFORMS[provider].limitation)console.log(PLATFORMS[provider].limitation);
  await terminal.question('完成后回到这里按回车，之后才开始观察响应（Ctrl+C 可停止）：',{signal:controller.signal});
  session.setPhase('manual_query');
  console.log('\n第二步：在官方只读查询页正常查一次流水；如果有分页，再查看下一页。不要付款或交易。');
  await terminal.question('等待记录显示后，回到这里按回车进入静默观察：',{signal:controller.signal});
  session.setPhase('idle');await observer.drain();
  if(session.counts.transportAuthDenied){session.setPhase('paused');throw new Error('AUTH_REQUIRED');}
  console.log(`\n第三步：现在 ${seconds} 秒内不要手动刷新、点击查询或切换账号。正在观察网页是否自行返回数据。`);
  session.setPhase('quiet_window');
  const started=Date.now();
  while(Date.now()-started<seconds*1000&&!controller.signal.aborted&&session.phase!=='paused'){
    await delay(1000,undefined,{signal:controller.signal}).catch(()=>{});
  }
  if(session.phase==='paused'){outcome='transport_denied';console.log('收到 401/403 响应，观察已暂停。请在官方界面核实登录和授权，不会自动重试。');}
  else if(!interrupted)outcome='completed_observation';
}catch{
  if(!interrupted){console.log('本次诊断未完成。可能是 Edge 未安装、已占用专用窗口、机构不支持此浏览器方式或登录/查询受限。不会尝试绕过。');process.exitCode=1;}
}finally{
  if(session){const finalPhase=session.phase;session.setPhase('idle');observer?.detach();await context?.close().catch(()=>{});await observer?.drain();session.setPhase(finalPhase==='paused'?'paused':'finished');
    const report={...session.report(),runOutcome:interrupted?'interrupted':outcome,observationSecondsRequested:seconds};const folder=path.join(process.env.LOCALAPPDATA||path.join(homedir(),'AppData','Local'),'YuliangFinance','reports');await mkdir(folder,{recursive:true});
    reportPath=path.join(folder,`Yuliang-Structure-${session.platform}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`);await writeFile(reportPath,JSON.stringify(report,null,2)+'\n',{mode:0o600});await chmod(reportPath,0o600).catch(()=>{});
    console.log(`\n已生成脱敏结构报告：\n${reportPath}\n只上传这个 JSON，不上传 profiles 文件夹、截图、HAR、浏览器日志或 Cookie。`);
    console.log(`候选结构 ${report.candidates.length} 个；静默阶段响应 ${report.candidates.reduce((s,c)=>s+c.quietWindowResponses,0)} 次。自动同步未验收。`);
  }
  terminal.close();process.off('SIGINT',onStop);process.off('SIGTERM',onStop);
}
