# 依赖与来源

生产扩展只使用标准浏览器 API，不包含第三方运行库、CDN、开源交易客户端或远程字体。新增 v0.3 Windows 本机诊断工具运行时需要锁定的 Playwright，由 npm 按下述版本安装；不随 ZIP 分发其二进制或源包，使用本机 Edge，不额外下载浏览器。本项目沿用仓库 MIT LICENSE。用户提供的原始源码/任务说明保留于 `docs/handoff`，原 ZIP 不变。

开发依赖锁定如下（2026-11-02 从 npm 核验，完整性由 package-lock.json 的 SHA-512 integrity 固定）：

| 包 | 版本 | 许可证 | 用途 |
| --- | --- | --- | --- |
| @playwright/test | 1.64.1 | Apache-2.0 | DOM / 界面测试断言及 Chromium 驱动 |
| playwright | 1.64.1 | Apache-2.0 | 上述包的传递依赖 |
| playwright-core | 1.64.1 | Apache-2.0 | 上述包的传递依赖 |

这些包需要 Node >=20；本项目开发命令要求 Node >=24，并以 `.node-version` 固定本次工具链。安装源为 registry.npmjs.org，当前云环境可安装；Windows 生产运行不访问 npm。开发时需要实际可用的 Chromium/Chrome 路径，管理员策略可能限制原生扩展加载；不要求关闭策略。

Chromium 由本次环境预装，不随 ZIP 分发；Playwright 及其 node_modules 也不随运行包分发。若未来分发测试工具本体，需包含其各自 LICENSE / NOTICE。

没有复制 Firefly III、Ghostfolio、AutoAccounting、easytrader 或其他候选项目。这些项目不构成当前金融账户接入能力，未因引用其名字而将其代码并入本项目。
