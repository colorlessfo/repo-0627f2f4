@echo off
setlocal
set DEBUG=
set PWDEBUG=
chcp 65001 >nul
cd /d "%~dp0"
echo 余量财务 · 本机收支接入诊断 v0.3
echo 本工具需要 Node.js 24+ 和已安装的 Microsoft Edge。
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)" >nul 2>&1
if errorlevel 1 (
  echo 请先从 https://nodejs.org/ 安装 Node.js 24 或更新版本，再双击本文件。
  pause
  exit /b 1
)
if not exist "node_modules\playwright\package.json" (
  echo 正在通过 npm 安装锁定的浏览器驱动，不会下载额外浏览器或修改 Edge 设置。
  call npm ci --include=dev --ignore-scripts --no-audit --no-fund
  if errorlevel 1 (
    echo 安装失败。请检查 npm 网络访问，不要关闭 TLS 或校验来重试。
    pause
    exit /b 1
  )
)
node tools\local-probe\run.mjs
set probe_status=%errorlevel%
echo.
echo 请只分享工具生成的脱敏结构报告 JSON；不要分享浏览器配置目录。
pause
exit /b %probe_status%
